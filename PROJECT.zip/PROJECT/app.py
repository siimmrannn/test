from flask import Flask,render_template,request,redirect,url_for,session
import pymysql

app=Flask(__name__)  
app.secret_key="your secret key"
'''
#YOUTUBE FILES-PART
@app.route("/")
def home():
    return render_template('indexx.html')


@app.route("/about")
def about():
    return render_template('about.html')


@app.route("/contact")
def contact():
    return render_template('contact.html')
'''

def home():
  
  return render_template('login.html')

@app.route('/Login')
def log():
    return render_template('login.html')  
    

 
@app.route('/insert',methods=["POST","GET"])
def insert():

 #if request.method=='POST' and 'username' in request.form and 'password' in request.form:

  uname=request.form['username']
  pwd=request.form['password']
  
  servername="localhost" 
  username="root"
  password="" 
  dbname="hospitalmanagementsystem"
  
  try:
     db=pymysql.connect(servername,username,password,dbname)
     cu=db.cursor()
     
     sql="insert into user_login(username,password)values('{}','{}')".format(uname,pwd) 
     
     cu.execute(sql)
     db.commit()
            
     return render_template('login.html')
     
  except Exception:
  
     return "error"                         


@app.route('/Register')
def reg():
    return render_template('/Register.html')
 
@app.route('/register',methods=["GET","POST"])
def Register():
    
    fname=request.form['firstname']
    lname=request.form['lastname']
    mnumber=request.form['mobilenumber']
    user=request.form['username']
    password=request.form['password']
    
    servername="localhost"
    username="root"
    password=""
    dbname="hospitalmanagementsystem"
    
    try:
       db=pymysql.connect(servername,username,password,dbname)
       cu=db.cursor()
       
       sql="insert into registration(FirstName,LastName,MobileNumber,Username,Password)values('{}','{}','{}','{}','{}')".format(fname,lname,mnumber,user,password)
       
       cu.execute(sql)
       db.commit()
       return redirect('/Login')
       
    except Exception:
       db.rollback()
       return "Error in try block" 

 
 
@app.route('/admin')
def admin_login(): 
    
    uname=request.form['username']
    pswd=request.form['password']
    
    if uname=='simran' and pswd=='simran123':
      return "succcess"
    else:
      return "Invalid"
      
 
 
@app.route('/dashboard')
def display():

   return render_template('/dashboard')

 
 



app.run(debug=True)





'''   
#TRYING SESSION PART-
  
     if account: 
      session['loggedin'] = True
      session['uname'] = account['username'] 
      session['pwd'] = account['password'] 
      msg = 'Logged in successfully !'
      return render_template('index.html', msg = msg) 
            
     else: 
      msg = 'Incorrect username / password !'
            
      return render_template('login.html', msg = msg) 
     
  except Exception:
  
     return "error"      
      
''' 